import './Loader.css'
export function Loader () {
    return (
        <div className="loading">
            <div className="loader"></div>
        </div>
    )
}
