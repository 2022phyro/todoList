import './PopUp.css'

export default function PopUp () {

    return (
        <div class="pop-up-wrapper">
            <div className="new-note">
            </div>
            <div className="decision">

            </div>
        </div>
    )
}